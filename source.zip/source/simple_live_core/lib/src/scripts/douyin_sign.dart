import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';

// ─── Constants ───────────────────────────────────────────────────────
const String kDefaultUserAgent =
    "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.5845.97 Safari/537.36 Core/1.116.567.400 QQBrowser/19.7.6764.400";

const String _s4 = "Dkdpgh2ZmsQB80/MfvV36XI1R45-WUAlEixNLwoqYTOPuzmFjJnry79HbGcaStCe";
const String _s3 = "ckdp1h4ZKsUB80/Mfvw36XIgR25+WQAlEi7NLboqYTOPuzmFjJnryx9HVGDaStCe";

const String kWindowEnv = "1536|747|1536|834|0|30|0|0|1536|834|1536|864|1525|747|24|24|Win32";

// ─── RC4 ─────────────────────────────────────────────────────────────
List<int> _rc4Init(String key) {
  var s = List<int>.generate(256, (i) => i);
  int j = 0;
  for (int i = 0; i < 256; i++) {
    j = (j + s[i] + key.codeUnitAt(i % key.length)[0]) & 0xff;
    final temp = s[i];
    s[i] = s[j];
    s[j] = temp;
  }
  return s;
}

String rc4Encrypt(String data, String key) {
  final s = _rc4Init(key);
  final cipher = <int>[];
  int i = 0, j = 0;
  final dataUnits = data.codeUnits;
  for (int k = 0; k < dataUnits.length; k++) {
    i = (i + 1) & 0xff;
    j = (j + s[i]) & 0xff;
    final temp = s[i];
    s[i] = s[j];
    s[j] = temp;
    final t = (s[i] + s[j]) & 0xff;
    cipher.add(s[t] ^ dataUnits[k]);
  }
  return String.fromCharCodes(cipher);
}

String rc4EncryptBytes(List<int> data, String key) {
  final s = _rc4Init(key);
  final cipher = <int>[];
  int i = 0, j = 0;
  for (int k = 0; k < data.length; k++) {
    i = (i + 1) & 0xff;
    j = (j + s[i]) & 0xff;
    final temp = s[i];
    s[i] = s[j];
    s[j] = temp;
    final t = (s[i] + s[j]) & 0xff;
    cipher.add(s[t] ^ data[k]);
  }
  return String.fromCharCodes(cipher);
}

// ─── SM3 ─────────────────────────────────────────────────────────────
const _sm3IV = [
  0x7380166f, 0x4914b2b9, 0x172442d7, 0xda8a0600,
  0xa96f30bc, 0x8317410a, 0xe3354271, 0x82873024,
];

int _Tj(int j) => (j < 16) ? 0x79cc4519 : 0x7a879d8a;

Uint8List sm3Digest(List<int> data) {
  final h = List<int>.from(_sm3IV);

  // Pad
  final buf = <int>[...data];
  buf.add(0x80);
  while ((buf.length * 8 + 64) % 512 != 0) buf.add(0);
  final msgBitLen = data.length * 8;
  for (int i = 63; i >= 0; i -= 8) {
    buf.add((msgBitLen >> i) & 0xff);
  }

  // Process each 64-byte block
  for (int off = 0; off < buf.length; off += 64) {
    final block = buf.sublist(off, off + 64);

    // Expand to 132 words
    final w = List<int>.filled(132, 0);
    for (int i = 0; i < 16; i++) {
      w[i] = ((block[i * 4] << 24) | (block[i * 4 + 1] << 16) |
              (block[i * 4 + 2] << 8) | block[i * 4 + 3]) &
          0xffffffff;
    }
    for (int n = 16; n < 68; n++) {
      int p1 = (w[n - 16] ^ w[n - 9]) & 0xffffffff;
      int p2 = ((w[n - 3] << 15) | (w[n - 3] >> 17)) & 0xffffffff;
      int p3 = ((w[n - 13] << 7) | (w[n - 13] >> 25)) & 0xffffffff;
      w[n] = ((p1 ^ p2 ^ p3 ^ w[n - 6]) & 0xffffffff);
    }
    for (int n = 0; n < 64; n++) {
      w[n + 68] = (w[n] ^ w[n + 4]) & 0xffffffff;
    }

    int a = h[0], b = h[1], c = h[2], d = h[3];
    int e = h[4], f = h[5], g = h[6], hh = h[7];

    for (int j = 0; j < 64; j++) {
      final Tj = _Tj(j);

      int SS1 = ((a << 12) | (a >> 20)) & 0xffffffff;
      SS1 = (SS1 + e + Tj) & 0xffffffff;
      SS1 = ((SS1 << 7) | (SS1 >> 25)) ^
          ((SS1 << 12) | (SS1 >> 20)) ^
          ((SS1 << 22) | (SS1 >> 10));
      SS1 &= 0xffffffff;

      int SS2 = (SS1 ^ ((hh << 12) | (hh >> 20))) & 0xffffffff;

      int ffVal;
      if (j < 16) {
        ffVal = (a ^ b ^ c) & 0xffffffff;
      } else {
        ffVal = ((a & b) | (a & d) | (b & d)) & 0xffffffff;
      }

      int ggVal;
      if (j < 16) {
        ggVal = (e ^ f ^ g) & 0xffffffff;
      } else {
        ggVal = ((e & f) | ((~e & 0xffffffff) & g)) & 0xffffffff;
      }

      final tt1 = (ffVal + d + SS2 + w[j + 68]) & 0xffffffff;
      final tt2 = (ggVal + hh + SS1 + w[j]) & 0xffffffff;

      d = c;
      c = (b << 9 | b >> 23) & 0xffffffff;
      b = a;
      a = tt1;
      hh = g;
      g = (f << 19 | f >> 13) & 0xffffffff;
      f = e;
      e = ((tt2 ^ (tt2 << 9 | tt2 >> 23) ^ (tt2 << 17 | tt2 >> 15)) &
          0xffffffff);
    }

    for (int i = 0; i < 8; i++) {
      h[i] = (h[i] ^ [a, b, c, d, e, f, g, hh][i]) & 0xffffffff;
    }
  }

  // Little-endian output
  final result = <int>[];
  for (int i = 0; i < 8; i++) {
    final v = h[i];
    result.addAll([v & 0xff, (v >> 8) & 0xff, (v >> 16) & 0xff, (v >> 24) & 0xff]);
  }
  return Uint8List.fromList(result);
}

// Double SM3 hash (used in abogus)
Uint8List sm3Double(List<int> data) => sm3Digest(sm3Digest(data));

// ─── Custom base64 (result_encrypt) ──────────────────────────────────
String resultEncryptWithAlphabet(String input, String alphabet) {
  String result = '';
  final len = input.length;
  for (int i = 0; i < len ~/ 3 * 4; i++) {
    int round = i ~/ 4;
    int offset = round * 3;
    if (offset + 2 >= len) break;

    final a = input.codeUnitAt(offset)[0];
    final b = input.codeUnitAt(offset + 1)[0];
    final c = input.codeUnitAt(offset + 2)[0];
    int triple = (a << 16) | (b << 8) | c;

    int key;
    switch (i % 4) {
      case 0:
        key = (triple >> 18) & 0x3f;
        break;
      case 1:
        key = (triple >> 12) & 0x3f;
        break;
      case 2:
        key = (triple >> 6) & 0x3f;
        break;
      default:
        key = triple & 0x3f;
    }
    result += alphabet[key];
  }
  return result;
}

String resultEncrypt(String input) => resultEncryptWithAlphabet(input, _s4);

// ─── gener_random ────────────────────────────────────────────────────
List<int> generRandom(int random, List<int> option) {
  return [
    (random & 0xff & 0xaa) | (option[0] & 0x55), // 163
    (random & 0xff & 0x55) | (option[0] & 0xaa), // 87
    ((random >> 8) & 0xff & 0xaa) | (option[1] & 0x55), // 37
    ((random >> 8) & 0xff & 0x55) | (option[1] & 0xaa), // 41
  ];
}

String generateRandomStr(Random rng) {
  final r1 = generRandom(rng.nextInt(10000), [3, 45]);
  final r2 = generRandom(rng.nextInt(10000), [1, 0]);
  final r3 = generRandom(rng.nextInt(10000), [1, 5]);
  return String.fromCharCodes([...r1, ...r2, ...r3]);
}

// ─── a_bogus generation ──────────────────────────────────────────────
class _AbogusB {
  final _data = <int, int>{};
  void set(int k, int v) => _data[k] = v;
  int get(int k) => _data[k] ?? 0;
}

List<int> _generateRc4BbStr(
  String urlSearchParams,
  String userAgent,
  String windowEnvStr,
  Random rng,
) {
  final cus = 'cus';

  // SM3 hashes
  final urlDouble = sm3Double(utf8.encode(urlSearchParams + cus));
  final cusDouble = sm3Double(utf8.encode(cus));

  // UA processing: rc4(ua, chars([0.00390625, 1, 14])) then result_encrypt with s3
  final uaKeyStr = String.fromCharCodes([
    (0.00390625).toInt() & 0xff,
    1 & 0xff,
    14 & 0xff,
  ]);
  final uaEncrypted = rc4Encrypt(userAgent, uaKeyStr);
  final uaEncoded = resultEncryptWithAlphabet(uaEncrypted, _s3);
  final uaPart = sm3Digest(utf8.encode(uaEncoded));

  final now = DateTime.now().millisecondsSinceEpoch;
  final startMs = now - rng.nextInt(300) - 100;

  final b = _AbogusB();
  b.set(8, 3);
  b.set(10, now);
  b.set(15, 6241); // pageId
  b.set(16, startMs);
  b.set(18, 44);
  b.set(19, 5);

  final args = [0, 1, 14];

  // startMs bytes
  b.set(20, (startMs >> 24) & 0xff);
  b.set(21, (startMs >> 16) & 0xff);
  b.set(22, (startMs >> 8) & 0xff);
  b.set(23, startMs & 0xff);
  b.set(24, startMs ~/ 268435456);
  b.set(25, startMs ~/ 68719476736);

  // args[0] = 0
  b.set(26, (args[0] >> 24) & 0xff);
  b.set(27, (args[0] >> 16) & 0xff);
  b.set(28, (args[0] >> 8) & 0xff);
  b.set(29, args[0] & 0xff);

  // args[1] = 1
  b.set(30, (args[1] ~/ 256) & 0xff);
  b.set(31, args[1] % 256);
  b.set(32, (args[1] >> 24) & 0xff);
  b.set(33, (args[1] >> 16) & 0xff);

  // args[2] = 14
  b.set(34, (args[2] >> 24) & 0xff);
  b.set(35, (args[2] >> 16) & 0xff);
  b.set(36, (args[2] >> 8) & 0xff);
  b.set(37, args[2] & 0xff);

  // SM3 results
  b.set(38, urlDouble[21]);
  b.set(39, urlDouble[22]);
  b.set(40, cusDouble[21]);
  b.set(41, cusDouble[22]);
  b.set(42, uaPart[23]);
  b.set(43, uaPart[24]);

  // now bytes
  b.set(44, (now >> 24) & 0xff);
  b.set(45, (now >> 16) & 0xff);
  b.set(46, (now >> 8) & 0xff);
  b.set(47, now & 0xff);
  b.set(48, b.get(8));
  b.set(49, now ~/ 268435456);
  b.set(50, now ~/ 68719476736);

  // pageId bytes
  final pageId = b.get(15);
  b.set(51, pageId);
  b.set(52, (pageId >> 24) & 0xff);
  b.set(53, (pageId >> 16) & 0xff);
  b.set(54, (pageId >> 8) & 0xff);
  b.set(55, pageId & 0xff);

  // aid = 6383
  const aid = 6383;
  b.set(56, aid);
  b.set(57, aid & 0xff);
  b.set(58, (aid >> 8) & 0xff);
  b.set(59, (aid >> 16) & 0xff);
  b.set(60, (aid >> 24) & 0xff);

  // window env
  final windowEnvList = windowEnvStr.codeUnits;
  b.set(64, windowEnvList.length);
  b.set(65, b.get(64) & 0xff);
  b.set(66, (b.get(64) >> 8) & 0xff);

  b.set(69, 0);
  b.set(70, 0);
  b.set(71, 0);

  // XOR
  int xor = 0;
  for (final k in [
    18, 20, 52, 26, 30, 34, 58, 38, 40, 53, 42, 21, 27, 54, 55, 31,
    35, 57, 39, 41, 43, 22, 28, 32, 60, 36, 23, 29, 33, 37, 44, 45,
    59, 46, 47, 48, 49, 50, 24, 25, 65, 66, 70, 71,
  ]) {
    xor ^= b.get(k);
  }
  b.set(72, xor);

  // Build bb
  final bbIdx = [
    18, 20, 52, 26, 30, 34, 58, 38, 40, 53, 42, 21, 27, 54, 55, 31,
    35, 57, 39, 41, 43, 22, 28, 32, 60, 36, 23, 29, 33, 37, 44, 45,
    59, 46, 47, 48, 49, 50, 24, 25, 65, 66, 70, 71,
  ];
  final bb = bbIdx.map(b.get).toList();
  final combined = [...bb, ...windowEnvList, b.get(72)];

  return rc4EncryptBytes(combined, String.fromCharCodes([121])).codeUnits;
}

// ─── DouyinSign API ──────────────────────────────────────────────────
class DouyinSign {
  static const String defaultUserAgent = kDefaultUserAgent;

  static String generateMsToken(int length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    final random = Random.secure();
    return List.generate(length, (_) => chars[random.nextInt(chars.length)]).join();
  }

  /// Generate a_bogus signature for the given URL.
  static String getAbogusUrl(String url, String userAgent) {
    final rng = Random();
    final msToken = generateMsToken(107);

    // Parse URL params (mirrors JS: ('$url&msToken=$msToken').split('?')[1])
    final joinedUrl = '$url&msToken=$msToken';
    final params = joinedUrl.split('?')[1];
    final query = params.contains('?') ? params.split('?')[1] : params;

    final bbBytes = _generateRc4BbStr(
      query,
      userAgent,
      kWindowEnv,
      rng,
    );

    final randomStr = generateRandomStr(rng);
    final combined = '$randomStr${String.fromCharCodes(bbBytes)}';
    final abogus = resultEncrypt(combined) + '=';

    // Match original JS: always append msToken and a_bogus to the full URL
    return '$url&msToken=${Uri.encodeComponent(msToken)}&a_bogus=${Uri.encodeComponent(abogus)}';
  }

  /// MSSDK signature fallback.
  /// The original is ~10000 lines of heavily obfuscated JS.
  /// Returns a safe placeholder to prevent crashes.
  static String getSignature(String roomId, String uniqueId) {
    return '00000000';
  }

  /// Generate msStub (MD5-based, used by MSSDK).
  static String getMsStub(String roomId, String uniqueId) {
    final params = {
      "live_id": "1",
      "aid": "6383",
      "version_code": 180800,
      "webcast_sdk_version": "1.3.0",
      "room_id": roomId,
      "sub_room_id": "",
      "sub_channel_id": "",
      "did_rule": "3",
      "user_unique_id": uniqueId,
      "device_platform": "web",
      "device_type": "",
      "ac": "",
      "identity": "audience",
    };
    final sigParams = params.entries.map((e) => "${e.key}=${e.value}").join(',');
    return md5.convert(sigParams.codeUnits).toString();
  }
}
