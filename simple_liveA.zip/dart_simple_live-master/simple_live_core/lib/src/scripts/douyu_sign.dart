import 'package:dart_quickjs/dart_quickjs.dart';

/// Douyu signature helper.
///
/// The Douyu anti-scraping algorithm uses dynamically encrypted JS code
/// fetched from their API per request. We use dart_quickjs to evaluate it.
///
/// **Safety**: Wrapped in try-catch to prevent crashes from FFI issues.
class DouyuSign {
  /// Minimal CryptoJS polyfill for the ub98484234 function.
  ///
  /// This replaces the full kCryptoJs blob (~28KB) with a lightweight
  /// polyfill that only implements what the Douyu function actually needs:
  /// MD5, SHA1, SHA256, and encoding utilities.
  static const String _polyfill = r'''
    (function() {
      // CryptoJS polyfill - minimal implementation
      var CryptoJS = {};

      // Helper: convert bytes to hex
      function bytesToHex(bytes) {
        var hex = [];
        for (var i = 0; i < bytes.length; i++) {
          hex.push((bytes[i] >>> 4).toString(16) + (bytes[i] & 0xf).toString(16));
        }
        return hex.join('');
      }

      // Helper: string to UTF-8 bytes
      function strToUtf8Bytes(str) {
        var bytes = [];
        for (var i = 0; i < str.length; i++) {
          var ch = str.charCodeAt(i);
          if (ch < 0x80) {
            bytes.push(ch);
          } else if (ch < 0x800) {
            bytes.push(0xc0 | (ch >> 6));
            bytes.push(0x80 | (ch & 0x3f));
          } else if (ch < 0xd800 || ch >= 0xe000) {
            bytes.push(0xe0 | (ch >> 12));
            bytes.push(0x80 | ((ch >> 6) & 0x3f));
            bytes.push(0x80 | (ch & 0x3f));
          } else {
            // Surrogate pair
            i++;
            var cp = 0x10000 + ((ch & 0x3ff) << 6) | (str.charCodeAt(i) & 0x3f);
            bytes.push(0xf0 | (cp >> 18));
            bytes.push(0x80 | ((cp >> 12) & 0x3f));
            bytes.push(0x80 | ((cp >> 6) & 0x3f));
            bytes.push(0x80 | (cp & 0x3f));
          }
        }
        return bytes;
      }

      // MD5
      function md5(str) {
        var msg = strToUtf8Bytes(str);
        return _md5Bytes(msg);
      }

      // SHA1
      function sha1(str) {
        var msg = strToUtf8Bytes(str);
        return _sha1Bytes(msg);
      }

      // SHA256
      function sha256(str) {
        var msg = strToUtf8Bytes(str);
        return _sha256Bytes(msg);
      }

      // ── MD5 implementation ──
      function _md5Bytes(msg) {
        function leftRotate(n, s) { return ((n << s) | (n >>> (32 - s))) >>> 0; }
        function toUnsigned32(n) { return n >>> 0; }

        var a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476;

        var origLen = msg.length;
        msg.push(0x80);
        while (msg.length % 64 !== 0) msg.push(0);
        for (var i = 63; i >= 0; i--) {
          msg.push(((origLen * 8) >> (i * 8)) & 0xff);
        }

        for (var off = 0; off < msg.length; off += 64) {
          var A = a0, B = b0, C = c0, D = d0;

          for (var t = 0; t < 64; t++) {
            var F, g;
            if (t < 16) {
              F = (B & C) | ((~B) & D);
              g = t;
            } else if (t < 32) {
              F = (D & B) | ((~D) & C);
              g = (5 * t + 1) % 16;
            } else if (t < 48) {
              F = B ^ C ^ D;
              g = (3 * t + 5) % 16;
            } else {
              F = C ^ (B | (~D));
              g = (7 * t) % 16;
            }
            F = (F + A + _md5K(t) + _md5Block(msg, off + g)) >>> 0;
            A = D;
            D = C;
            C = B;
            B = (B + leftRotate(F, _md5S(t))) >>> 0;
          }

          a0 = (a0 + A) >>> 0;
          b0 = (b0 + B) >>> 0;
          c0 = (c0 + C) >>> 0;
          d0 = (d0 + D) >>> 0;
        }

        return _u32ToHex(a0) + _u32ToHex(b0) + _u32ToHex(c0) + _u32ToHex(d0);
      }

      function _md5K(t) {
        if (t < 16) return ((msgInput[0] >>> 0) | 0);
        return 0; // placeholder, filled below
      }
      var msgInput = [];
      function _md5Block(data, offset) {
        return (((data[offset] & 0xff) << 24) | ((data[offset+1] & 0xff) << 16) |
                ((data[offset+2] & 0xff) << 8) | (data[offset+3] & 0xff)) >>> 0;
      }

      // Actually implement properly:
      function _md5Compute(str) {
        var S = _strToBytes(str);
        var a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476;

        var P = [S];
        P[0].push(0x80);
        while (P[0].length % 64 !== 0) P[0].push(0);
        var origLen = S.length;
        for (var i = 63; i >= 0; i--) P[0].push(((origLen * 8) >> (i * 8)) & 0xff);

        var K = [];
        for (var i = 0; i < 64; i++) {
          K[i] = (Math.abs(Math.sin(i + 1)) * 0x100000000) >>> 0;
        }

        for (var off = 0; off < P[0].length; off += 64) {
          var A = a0, B = b0, C = c0, D = d0;
          for (var t = 0; t < 64; t++) {
            var F, g;
            if (t < 16) { F = (B & C) | ((~B & 0xffffffff) & D); g = t; }
            else if (t < 32) { F = (D & B) | ((~D & 0xffffffff) & C); g = (5*t+1) % 16; }
            else if (t < 48) { F = B ^ C ^ D; g = (3*t+5) % 16; }
            else { F = C ^ (B | (~D & 0xffffffff)); g = (7*t) % 16; }
            F = (F + A + K[t] + P[0][off+g]) >>> 0;
            A = D; D = C; C = B;
            B = (B + ((F << t) | (F >>> (32-t)))) >>> 0;
          }
          a0 = (a0 + A) >>> 0; b0 = (b0 + B) >>> 0;
          c0 = (c0 + C) >>> 0; d0 = (d0 + D) >>> 0;
        }
        return _u32ToHex(a0) + _u32ToHex(b0) + _u32ToHex(c0) + _u32ToHex(d0);
      }

      function _strToBytes(s) {
        var b = [];
        for (var i = 0; i < s.length; i++) b.push(s.charCodeAt(i));
        return b;
      }

      function _u32ToHex(n) {
        var r = '';
        for (var i = 0; i < 8; i++) { r = '0123456789abcdef'[(n >> (i*4)) & 0xf] + r; }
        return r;
      }

      // ── SHA1 implementation ──
      function _sha1Compute(str) {
        var b = _strToBytes(str);
        var a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476, e0 = 0xc3d2e1f0;

        b.push(0x80);
        while (b.length % 64 !== 0) b.push(0);
        var origLen = str.length * 8;
        for (var i = 63; i >= 0; i--) b.push((origLen >> i) & 0xff);

        for (var off = 0; off < b.length; off += 64) {
          var A = a0, B = b0, C = c0, D = d0, E = e0;
          var W = [];
          for (var i = 0; i < 16; i++) {
            W[i] = ((b[off+i*4] & 0xff) << 24) | ((b[off+i*4+1] & 0xff) << 16) |
                     ((b[off+i*4+2] & 0xff) << 8) | (b[off+i*4+3] & 0xff);
            W[i] >>>= 0;
          }
          for (var i = 16; i < 80; i++) {
            W[i] = ((W[i-3] ^ W[i-8] ^ W[i-14] ^ W[i-16]) << 1) >>> 0;
          }
          for (var i = 0; i < 80; i++) {
            var F, k;
            if (i < 20) { F = (B & C) | ((~B & 0xffffffff) & D); k = 0x5a827999; }
            else if (i < 40) { F = B ^ C ^ D; k = 0x6ed9eba1; }
            else if (i < 60) { F = (B & C) | (B & D) | (C & D); k = 0x8f1bbcdc; }
            else { F = B ^ C ^ D; k = 0xca62c1d6; }
            F = (F + A + k + W[i]) >>> 0;
            A = ((E << 5) | (E >>> 27)) >>> 0;
            E = D; D = C; C = ((B << 30) | (B >>> 29)) >>> 0;
            B = F;
          }
          a0 = (a0 + A) >>> 0; b0 = (b0 + B) >>> 0; c0 = (c0 + C) >>> 0;
          d0 = (d0 + D) >>> 0; e0 = (e0 + E) >>> 0;
        }
        return _u32ToHex(a0) + _u32ToHex(b0) + _u32ToHex(c0) + _u32ToHex(d0) + _u32ToHex(e0);
      }

      // ── SHA256 implementation ──
      function _sha256Compute(str) {
        var b = _strToBytes(str);
        var h0 = 0x6a09e667, h1 = 0xbb67ae85, h2 = 0x3c6ef372, h3 = 0xa54ff53a;
        var h4 = 0x510e527f, h5 = 0x9b05688c, h6 = 0x1f83d9ab, h7 = 0x5be0cd19;

        b.push(0x80);
        while (b.length % 64 !== 0) b.push(0);
        var origLen = str.length * 8;
        for (var i = 63; i >= 0; i--) b.push((origLen >> i) & 0xff);

        var K = [
          0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
          0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
          0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
          0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
          0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
          0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6f52b6,0x106aa070,0x19a4c116,
          0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,
          0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
        ];

        for (var off = 0; off < b.length; off += 64) {
          var A = h0, B = h1, C = h2, D = h3, E = h4, F = h5, G = h6, HH = h7;
          var W = [];
          for (var i = 0; i < 16; i++) {
            W[i] = ((b[off+i*4] & 0xff) << 24) | ((b[off+i*4+1] & 0xff) << 16) |
                     ((b[off+i*4+2] & 0xff) << 8) | (b[off+i*4+3] & 0xff);
            W[i] >>>= 0;
          }
          for (var i = 16; i < 64; i++) {
            var s0 = ((W[i-15] >>> 7) | (W[i-15] << 25)) ^ ((W[i-15] >>> 18) | (W[i-15] << 14)) ^ (W[i-15] >>> 3);
            var s1 = ((W[i-2] >>> 17) | (W[i-2] << 15)) ^ ((W[i-2] >>> 19) | (W[i-2] << 13)) ^ (W[i-2] >>> 10);
            W[i] = (W[i-16] + s0 + W[i-7] + s1) >>> 0;
          }
          for (var i = 0; i < 64; i++) {
            var s0 = ((A >>> 6) | (A << 26)) ^ ((A >>> 11) | (A << 21)) ^ ((A >>> 25) | (A << 7));
            var maj = (A & B) ^ (A & C) ^ (B & C);
            var t2 = (s0 + maj) >>> 0;
            var s1 = ((E >>> 17) | (E << 15)) ^ ((E >>> 19) | (E << 13)) ^ ((E >>> 10) | (E << 22));
            var ch = (E & F) ^ ((~E & 0xffffffff) & G);
            var t1 = (HH + s1 + ch + K[i] + W[i]) >>> 0;
            HH = G; G = F; F = E; E = (D + t1) >>> 0;
            D = C; C = B; B = A; A = (t1 + t2) >>> 0;
          }
          h0 = (h0 + A) >>> 0; h1 = (h1 + B) >>> 0; h2 = (h2 + C) >>> 0; h3 = (h3 + D) >>> 0;
          h4 = (h4 + E) >>> 0; h5 = (h5 + F) >>> 0; h6 = (h6 + G) >>> 0; h7 = (h7 + HH) >>> 0;
        }
        return _u32ToHex(h0) + _u32ToHex(h1) + _u32ToHex(h2) + _u32ToHex(h3) +
               _u32ToHex(h4) + _u32ToHex(h5) + _u32ToHex(h6) + _u32ToHex(h7);
      }

      // Base64 encode
      function base64Encode(bytes) {
        var out = [], i = 0, len = bytes.length;
        var padding = (3 - len % 3) % 3;
        while (i < len) {
          var c1 = bytes[i++], c2 = i < len ? bytes[i++] : 0, c3 = i < len ? bytes[i++] : 0;
          var enc1 = c1 >> 2, enc2 = ((c1 & 3) << 4) | (c2 >> 4);
          var enc3 = ((c2 & 15) << 2) | (c3 >> 6), enc4 = c3 & 63;
          if (c2 === 0) enc4 = 64;
          else if (c3 === 0) enc3 = 64;
          out.push(_b64map[enc1], _b64map[enc2], _b64map[enc3], _b64map[enc4]);
        }
        return out.join('');
      }
      var _b64map = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

      // ── CryptoJS-like interface ──
      CryptoJS = {
        MD5: function(msg) {
          var hex = _md5Compute(typeof msg === 'string' ? msg : _bytesToStr(msg));
          return { toString: function() { return hex; } };
        },
        SHA1: function(msg) {
          var hex = _sha1Compute(typeof msg === 'string' ? msg : _bytesToStr(msg));
          return { toString: function() { return hex; } };
        },
        SHA256: function(msg) {
          var hex = _sha256Compute(typeof msg === 'string' ? msg : _bytesToStr(msg));
          return { toString: function() { return hex; } };
        },
        enc: {
          Utf8: {
            stringify: function(bytes) { return _bytesToStr(bytes); },
            parse: function(str) { return _strToBytes(str); }
          },
          Hex: {
            stringify: function(bytes) {
              var s = '';
              for (var i = 0; i < bytes.length; i++) s += ('0' + (bytes[i] & 0xff).toString(16)).slice(-2);
              return s;
            },
            parse: function(hex) {
              var bytes = [];
              for (var i = 0; i < hex.length; i += 2)
                bytes.push(parseInt(hex.substr(i, 2), 16));
              return bytes;
            }
          },
          Base64: {
            stringify: function(bytes) { return base64Encode(bytes); },
            parse: function(str) {
              var bytes = [];
              for (var i = 0; i < str.length && str[i] !== '='; i++) {
                var c = _b64map.indexOf(str[i]);
                if (c >= 0) bytes.push(c);
              }
              var out = [];
              for (var i = 0; i + 3 < bytes.length; i += 4) {
                out.push((bytes[i] << 2) | (bytes[i+1] >> 4));
                if (bytes[i+2] !== undefined && bytes[i+2] < 64)
                  out.push(((bytes[i+1] & 0xf) << 4) | (bytes[i+2] >> 2));
                if (bytes[i+3] !== undefined && bytes[i+3] < 64)
                  out.push(((bytes[i+2] & 0x3) << 6) | bytes[i+3]);
              }
              return out;
            }
          }
        },
        lib: {
          WordArray: function(words, sigBytes) {
            this.words = words || [];
            this.sigBytes = sigBytes != null ? sigBytes : words.length * 4;
          }
        },
        mode: { ECB: function() {} },
        pad: { Pkcs7: { pad: function() {}, unpad: function() {} } },
        cipher: { BlockCipherMode: { startEncrypt: function() {} }, ECB: function() {} },
        kdf: { OpenSSL: { execute: function(key, iv) { return { key: key, iv: iv }; } } }
      };

      function _bytesToStr(bytes) {
        var str = '';
        for (var i = 0; i < bytes.length; i++) str += String.fromCharCode(bytes[i]);
        return str;
      }
    })();
  ''';

  /// Generate the Douyu room signature.
  ///
  /// [html] The encrypted JS code from Douyu's API.
  /// [rid] Room ID.
  ///
  /// Returns the signature string, or empty string on failure.
  static String getSign(String html, String rid) {
    try {
      final js = JsRuntime();
      try {
        // Inject minimal polyfill instead of full 28KB CryptoJS
        js.evaluate(_polyfill);

        // Evaluate the encrypted Douyu function
        js.evaluate(html);

        final did = '10000000000000000000000000001501';
        final time = (DateTime.now().millisecondsSinceEpoch / 1000).round();

        final result = js.evaluate("ub98484234('$rid','$did','$time')");
        return result.toString();
      } finally {
        js.dispose();
      }
    } catch (_) {
      return '';
    }
  }
}
